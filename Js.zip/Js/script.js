console.log("hello javascript");//แสดงผลในคอนโซล
console.log("hello Thursday");
document.getElementById("text").innerHTML = "Ohmyy";
document.write("Hello document write");