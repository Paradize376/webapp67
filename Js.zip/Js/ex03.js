const digitize = n => [...`${n}`].map(i=>parseInt(i));
const result1 = digitize(123);
console.log(result1);
 
const result2 = digitize(1230);
console.log(result2);