const random_Number_In_Range = (min, max)=> Math.random()*(max - min)+min;
 
const random1 = random_Number_In_Range(2, 10);
console.log(random1); 
 
 
const random2 = random_Number_In_Range(1, 5);
document.write(random2); 